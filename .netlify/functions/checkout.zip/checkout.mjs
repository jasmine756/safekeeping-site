
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/checkout.mjs
import crypto from "node:crypto";

// netlify/lib/services.mjs
var env = (k) => {
  const v = process.env[k];
  if (!v) throw new Error(`Missing environment variable ${k}`);
  return v;
};
async function sb(path, { method = "GET", body, prefer } = {}) {
  const url = env("SUPABASE_URL").replace(/\/+$/, "") + "/rest/v1/" + path;
  const key = env("SUPABASE_SERVICE_ROLE_KEY");
  const res = await fetch(url, {
    method,
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      ...prefer ? { Prefer: prefer } : {}
    },
    body: body ? JSON.stringify(body) : void 0
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`Supabase ${res.status}: ${text}`);
  return text ? JSON.parse(text) : null;
}
function formEncode(obj, prefix, out = []) {
  for (const [k, v] of Object.entries(obj)) {
    if (v === void 0 || v === null) continue;
    const key = prefix ? `${prefix}[${k}]` : k;
    if (typeof v === "object") formEncode(v, key, out);
    else out.push(`${encodeURIComponent(key)}=${encodeURIComponent(v)}`);
  }
  return out.join("&");
}
async function stripe(path, params, method = "POST") {
  const res = await fetch("https://api.stripe.com/v1/" + path, {
    method,
    headers: {
      Authorization: `Bearer ${env("STRIPE_SECRET_KEY")}`,
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: params ? formEncode(params) : void 0
  });
  const data = await res.json();
  if (!res.ok) throw new Error(`Stripe ${res.status}: ${data?.error?.message}`);
  return data;
}
var json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { "Content-Type": "application/json" }
});

// site/shop/shipping.js
var RATES = {
  mediaFirst: 499,
  // USPS Media Mail, first book/CD
  mediaEach: 100,
  // each extra book/CD
  groundDefault: {
    // USPS Ground Advantage when an item has no custom price
    magazine: 799,
    decor: 1199,
    other: 999,
    book: 799,
    // only used if a book is set to ground
    cd: 799
  },
  groundEach: 200,
  // each extra item in a ground box
  freeOverCents: null
  // e.g. 4000 = free shipping on orders $40+. null = off
};
function groundPrice(item) {
  if (Number.isInteger(item.ship_price_cents)) return item.ship_price_cents;
  return RATES.groundDefault[item.category] ?? RATES.groundDefault.other;
}
function quoteShipping(items) {
  if (!items.length) return { cents: 0, label: "", method: "none" };
  const subtotal = items.reduce((s, i) => s + i.price_cents, 0);
  if (RATES.freeOverCents && subtotal >= RATES.freeOverCents) {
    return { cents: 0, label: "Free shipping", method: "free" };
  }
  const allMedia = items.every((i) => i.ship_class === "media");
  if (allMedia) {
    return {
      cents: RATES.mediaFirst + RATES.mediaEach * (items.length - 1),
      label: "USPS Media Mail (2\u20138 business days)",
      method: "media"
    };
  }
  const top = Math.max(...items.map(groundPrice));
  return {
    cents: top + RATES.groundEach * (items.length - 1),
    label: "USPS Ground Advantage (2\u20135 business days)",
    method: "ground"
  };
}

// netlify/functions/checkout.mjs
var HOLD_MINUTES = 35;
var MAX_ITEMS = 20;
var checkout_default = async (req) => {
  if (req.method !== "POST") return json({ error: "Use POST" }, 405);
  let ids;
  try {
    ({ ids } = await req.json());
  } catch {
    return json({ error: "Bad request" }, 400);
  }
  ids = [...new Set((ids || []).filter((x) => typeof x === "string"))];
  if (!ids.length || ids.length > MAX_ITEMS) {
    return json({ error: "Your bag is empty." }, 400);
  }
  const now = /* @__PURE__ */ new Date();
  const holdUntil = new Date(now.getTime() + HOLD_MINUTES * 60 * 1e3);
  const token = crypto.randomUUID();
  const idList = ids.map((i) => `"${i.replace(/"/g, "")}"`).join(",");
  const claimed = await sb(
    `products?id=in.(${idList})&or=(status.eq.available,and(status.eq.reserved,reserved_until.lt.${now.toISOString()}))`,
    {
      method: "PATCH",
      prefer: "return=representation",
      body: { status: "reserved", hold_token: token, reserved_until: holdUntil.toISOString() }
    }
  );
  const release = () => sb(`products?hold_token=eq.${token}&status=eq.reserved`, {
    method: "PATCH",
    body: { status: "available", hold_token: null, reserved_until: null }
  });
  if (claimed.length !== ids.length) {
    await release();
    const got = new Set(claimed.map((p) => p.id));
    return json(
      { error: "Someone got to it first.", unavailable: ids.filter((i) => !got.has(i)) },
      409
    );
  }
  try {
    const origin = process.env.URL_OVERRIDE || new URL(req.url).origin;
    const ship = quoteShipping(claimed);
    const abs = (src) => /^https?:/.test(src) ? src : `${origin}/${src.replace(/^\/+/, "")}`;
    const params = {
      mode: "payment",
      success_url: `${origin}/shop/thanks/?session={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/shop/?canceled=1`,
      expires_at: Math.floor(holdUntil.getTime() / 1e3),
      shipping_address_collection: { allowed_countries: { 0: "US" } },
      phone_number_collection: { enabled: "false" },
      metadata: { hold_token: token, product_ids: claimed.map((p) => p.id).join(",").slice(0, 500) },
      payment_intent_data: { metadata: { hold_token: token } },
      line_items: {},
      shipping_options: {
        0: {
          shipping_rate_data: {
            type: "fixed_amount",
            display_name: ship.label,
            fixed_amount: { amount: ship.cents, currency: "usd" },
            tax_behavior: "exclusive"
          }
        }
      }
    };
    claimed.forEach((p, i) => {
      params.line_items[i] = {
        quantity: 1,
        price_data: {
          currency: "usd",
          unit_amount: p.price_cents,
          tax_behavior: "exclusive",
          product_data: {
            name: p.title,
            description: [p.creator, p.year, p.condition].filter(Boolean).join(" \xB7 ") || void 0,
            images: p.images?.[0] ? { 0: abs(p.images[0]) } : void 0,
            metadata: { product_id: p.id }
          }
        }
      };
    });
    if (process.env.STRIPE_TAX === "on") params.automatic_tax = { enabled: "true" };
    const session = await stripe("checkout/sessions", params);
    return json({ url: session.url });
  } catch (err) {
    console.error(err);
    await release();
    return json({ error: "Checkout couldn't start. Please try again in a minute." }, 500);
  }
};
var config = { path: "/api/checkout" };
export {
  config,
  checkout_default as default
};
