
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/services.mjs
import crypto from "node:crypto";
var env = (k) => {
  const v = process.env[k];
  if (!v) throw new Error(`Missing environment variable ${k}`);
  return v;
};
async function sb(path, { method = "GET", body, prefer } = {}) {
  const url = env("SUPABASE_URL").replace(/\/+$/, "") + "/rest/v1/" + path;
  const key = env("SUPABASE_SERVICE_ROLE_KEY");
  const res = await fetch(url, {
    method,
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      ...prefer ? { Prefer: prefer } : {}
    },
    body: body ? JSON.stringify(body) : void 0
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`Supabase ${res.status}: ${text}`);
  return text ? JSON.parse(text) : null;
}
function verifyStripeSignature(rawBody, header, toleranceSec = 300) {
  const secret = env("STRIPE_WEBHOOK_SECRET");
  const parts = Object.fromEntries(
    (header || "").split(",").map((p) => p.split("=").map((s) => s.trim()))
  );
  const sigs = (header || "").split(",").filter((p) => p.trim().startsWith("v1=")).map((p) => p.trim().slice(3));
  const t = Number(parts.t);
  if (!t || !sigs.length) return false;
  if (Math.abs(Date.now() / 1e3 - t) > toleranceSec) return false;
  const expected = crypto.createHmac("sha256", secret).update(`${t}.${rawBody}`).digest("hex");
  return sigs.some(
    (s) => s.length === expected.length && crypto.timingSafeEqual(Buffer.from(s), Buffer.from(expected))
  );
}
var json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { "Content-Type": "application/json" }
});

// netlify/functions/stripe-webhook.mjs
var stripe_webhook_default = async (req) => {
  const raw = await req.text();
  if (!verifyStripeSignature(raw, req.headers.get("stripe-signature"))) {
    return json({ error: "Bad signature" }, 400);
  }
  const event = JSON.parse(raw);
  const s = event.data?.object || {};
  const token = s.metadata?.hold_token;
  if (!token) return json({ ignored: true });
  if (event.type === "checkout.session.completed" && s.payment_status === "paid") {
    const sold = await sb(`products?hold_token=eq.${token}`, {
      method: "PATCH",
      prefer: "return=representation",
      body: { status: "sold", sold_at: (/* @__PURE__ */ new Date()).toISOString(), reserved_until: null }
    });
    const details = s.customer_details || {};
    const shipping = s.collected_information?.shipping_details || s.shipping_details || null;
    await sb("orders?on_conflict=stripe_session_id", {
      method: "POST",
      prefer: "resolution=ignore-duplicates",
      body: {
        stripe_session_id: s.id,
        email: details.email || null,
        name: shipping?.name || details.name || null,
        shipping_address: shipping?.address || null,
        product_ids: sold.map((p) => p.id),
        subtotal_cents: s.amount_subtotal,
        shipping_cents: s.total_details?.amount_shipping ?? null,
        tax_cents: s.total_details?.amount_tax ?? null,
        total_cents: s.amount_total
      }
    });
  }
  if (event.type === "checkout.session.expired") {
    await sb(`products?hold_token=eq.${token}&status=eq.reserved`, {
      method: "PATCH",
      body: { status: "available", hold_token: null, reserved_until: null }
    });
  }
  return json({ received: true });
};
var config = { path: "/api/stripe-webhook" };
export {
  config,
  stripe_webhook_default as default
};
